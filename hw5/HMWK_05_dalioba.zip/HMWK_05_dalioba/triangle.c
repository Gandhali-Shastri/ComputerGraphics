// Dalio, Brian A.
// dalioba
// 2019-11-05
//----------------------------------------------------------
#include <stdio.h>

#include "line.h"
#include "triangle.h"

View *_view = NULL;

//----------------------------------------------------------
void dumpTriangle( Vertex *v1, Vertex *v2, Vertex *v3 )
{
  // TODO:  Draw the three lines that are made from v1, v2, and
  //        v3.  Be sure you use clipLine() first to see if the
  //        line needs to be drawn.  Use dumoLine() to generate
  //        the actual line.
}

//----------------------------------------------------------
void setPortal( View *v )
{
  // TODO:  Remember the view so it can be clipped against when
  //        triangles are drawn later.
}

//----------------------------------------------------------

