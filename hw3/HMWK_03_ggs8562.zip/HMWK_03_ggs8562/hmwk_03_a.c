// Dalio, Brian A.
// dalioba
// 2019-10-20
//----------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

#include "model.h"
#include "projection.h"
#include "view.h"

//----------------------------------------------------------
int main( int argc, char *argv[] )
{
  if ( argc != 3 ) {
    fprintf( stderr, "Usage: %s <modelFileName> <viewFileName>\n", argv[0] );
    exit( 1 );
  }

  //--------------------------------------
  // Load the model and dump its contents.
  Model *m;
  m = loadModel( argv[1] );
  dumpModel( m );

  // Load the view and dump its contents.
  putc( '\n', stdout );
  View *v;
  v = loadView( argv[2] );
  dumpView( v );

  // Rotate the vertices according to the Euler angles
  // specified in the view.  Then dump them.
  putc( '\n', stdout );
  printf("%d n",m->m_center.x);
  rotateVertexList( v, m->m_vertex, m->m_numVertices, m->m_center );
  printf( "#- Rotated vertices --------------------\n" );
  dumpVertexList( m->m_vertex, m->m_numVertices );
  printf( "#---------------------------------------\n" );

  // Compute the projecion according to the parameters given
  // in the view.  Then dump the projection.
  putc( '\n', stdout );
  Projection *p = computeProjection( v );
  dumpProjection( p );

  // Project the rotated vertices according to the just-computed
  // projection.  Then dump the projected vertices.
  putc( '\n', stdout );
  //printf("\nggg%d %d %d\n",m->m_vertex[0].x,m->m_vertex[1].y,m->m_vertex[2].z);
  projectVertexList( p, m->m_vertex, m->m_numVertices );
  printf( "#- Projected vertices ------------------\n" );
  dumpVertexList( m->m_vertex, m->m_numVertices );
  printf( "#---------------------------------------\n" );

  // Display the three rotated, projected vertices that make up
  // each triangle of the model.
  putc( '\n', stdout );
  printf( "#- Triangles to draw -------------------\n" );
  for ( int i=0; i<m->m_numFaces; i++ ) {
    // TODO: Retrieve the rotated/projected values of the three
    //       vertices making up face i.
    double v1pX = 0.0, v1pY = 0.0;
    double v2pX = 0.0, v2pY = 0.0;
    double v3pX = 0.0, v3pY = 0.0;
  
  /*
	int v1 = m->m_face[i].v1;
	int v2 = m->m_face[i].v2;
	int v3 = m->m_face[i].v3;
	
	v1pX = sx*(m->m_vertex[v1].x)+ax;
	v1pY = sy*(m->m_vertex[v1].y)+ay;
	v2pX = sx*(m->m_vertex[v2].x)+ax;
	v2pY = sy*(m->m_vertex[v2].y)+ay;
	v3pX = sx*(m->m_vertex[v3].x)+ax;
	v3pY = sy*(m->m_vertex[v3].y)+ay;
*/
    printf( "  [%5d] ( %8.1f, %8.1f ), ( %8.1f, %8.1f ), ( %8.1f, %8.1f )\n",
      i, v1pX, v1pY, v2pX, v2pY, v3pX, v3pY );
  }
  printf( "#---------------------------------------\n" );

  //--------------------------------------
  // All done!  Free up the allocated strucures.
  freeModel( m );
  freeView( v );
  freeProjection( p );
}

//----------------------------------------------------------

