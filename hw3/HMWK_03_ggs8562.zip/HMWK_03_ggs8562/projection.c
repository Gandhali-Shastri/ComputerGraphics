// Dalio, Brian A.
// dalioba
// 2019-10-20
//----------------------------------------------------------
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "projection.h"

//----------------------------------------------------------
Projection *allocProjection()
{
  Projection *p;

  p = (Projection *) calloc( 1, sizeof( Projection ) );
  if ( p == NULL ) {
    fprintf( stderr, "allocProjection: Unable to allocate Projection.\n" );
    exit( 1 );
  }

  return p;
}

//----------------------------------------------------------
Projection *computeProjection( View *v )
{
  Projection *p = allocProjection();

  // TODO: Compute the proper values of fx, fy, gx, gy, sx, sy,
  //       ax, and ay and store them in p->...
  //       Save the camera distance from the view in the
  //       projection.
  
	  double m_fx = 0.0, m_fy = 0.0;
	  double m_gx = 0.0, m_gy = 0.0;
	  double m_sx = 0.0, m_sy = 0.0;
	  double m_ax = 0.0, m_ay = 0.0;
	  printf("%d",v->m_worldXMin);
	  
	  p->m_fx =  -(v->m_worldXMin);
	  p->m_fy = -(v->m_worldYMin);
	  
	  p->m_gx = v->m_width * v->m_viewportXMin;
	  p->m_gy = v->m_height * v->m_viewportYMin;
	  
	  p->m_sx = v->m_width *(v->m_viewportXMax - v->m_viewportXMin)/ (v->m_worldXMax - v->m_worldXMin);
	  p->m_sy = v->m_height * (v->m_viewportYMax - v->m_viewportYMin)/ (v->m_worldYMax - v->m_worldYMin);
	  
	  p->m_ax = p->m_fx * p->m_sx + p->m_gx;
	  p->m_ay = p->m_fy * p->m_sy + p->m_gy;
	  
	  p->m_cameraDistance = v->m_cameraDistance;

  return p;
}

//----------------------------------------------------------
void dumpProjection( Projection *p )
{
  printf( "#- Projection parameters ---------------\n" );
  printf( "(fx, fy) : ( %13.6f, %13.6f )\n", p->m_fx, p->m_fy );
  printf( "(gx, gy) : ( %13.6f, %13.6f )\n", p->m_gx, p->m_gy );
  printf( "(sx, sy) : ( %13.6f, %13.6f )\n", p->m_sx, p->m_sy );
  printf( "(ax, ay) : ( %13.6f, %13.6f )\n", p->m_ax, p->m_ay );
  printf( "Camera distance : %13.6f\n", p->m_cameraDistance );
  printf( "#---------------------------------------\n" );
}

//----------------------------------------------------------
void freeProjection( Projection *p )
{
  free( p );
}

//----------------------------------------------------------
void projectVertexList( Projection *p, Vertex *v, int numVertices )
{
  // TODO: Using the projection parameters in p, traverse the
  //       given list of vertices (there are numVertices of them)
  //       and project each vertex:
  //         1. If camera distance is not 0.0, first do a
  //            perspective adjustment.
  //         2. Once the vertex is adjusted for perspective,
  //            calculate its corresponding screen coordinates.
  
	for ( int i=0; i<numVertices; i++ ) {
		/*if(p->m_cameraDistance != 0.0){
			Vertex *v  = model->m_vertex;
			double x =  v->x;
			double y =  v->y;
			double z =  v->z;
			
			double PX = p->m_sx * x + p->m_ax;
			double PY = p->m_sy * y + p->m_ay;
			double PZ = 0.0;
			printf("%d %d %d \n", x,y,z);
			printf("%d %d %d \n", PX,PY,PZ);
		}*/
			double x =  v[i].x;
			double y =  v[i].y;
			double z =  v[i].z;
			//printf("%d %d %d \n", x,y,z);
			double Xscreen = p->m_sx * x + p->m_ax;
			double Yscreen = p->m_sy * y + p->m_ay;
			double Zscreen = 0.0;
			printf("%d %d %d \n", Xscreen,Yscreen);
	}
}

//----------------------------------------------------------
#define DEGREES_TO_RADIANS(d) (M_PI*(d)/180.0)

void rotateVertexList( View *view, Vertex *vertex, int numVertices, Vertex center )
{
  // TODO: Using the Euler angles given in the view, traverse the
  //       given list of vertices (there are numVertices of them)
  //       and rotate each vertex.
  //
  //       Compute the r00 through r22 values and the ex, ey, ez
  //       values _before_ looping through the vertex list!
		double X =  DEGREES_TO_RADIANS(view->m_phi);
		double Y =  DEGREES_TO_RADIANS(view->m_theta);
		double Z =  DEGREES_TO_RADIANS(view->m_psi);
		
		float r00 = cos(Z) * cos(Y); 
		double r01 = -cos(Y) * sin(Z); 
		double r02 = sin(Y);
		
		double r10 = cos(X) * sin(Z) + cos(Z) * sin(X) * sin(Y); 
		double r11 = cos(X) * cos(Z) - sin(X)* sin(Z)* sin(Y); 
		double r12 = -cos(Y) * sin(X); 
		
		double r20 = -cos(Y) * cos(Z)*sin(X) + sin(X)*sin(Z); 
		double r21 = cos(X) * sin(Z)* sin(Y) + cos(Z) * sin(X);
		double r22 = cos(X) * cos(Y); 
		
		double ex,ey,ez = 0;
		
		ex = r00 * 
		
		//printf("x y z angle %d %d %d \n", X, Y, Z);
		//printf("%d %d %d \n %d %d %d \n %d %d %d\n", r00,r01,r02,r10,r11,r12, r20,r21,r22);
		
		printf("%d n",center.x);
		
		
}

//----------------------------------------------------------

