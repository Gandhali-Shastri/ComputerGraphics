// Dalio, Brian A.
// dalioba
// 2019-11-11

#if !defined( __CULL_H__ )
#define __CULL_H__

//----------------------------------------------------------
#include "vertex.h"

//----------------------------------------------------------
int cull( Vertex *v1, Vertex *v2, Vertex *v3, Vertex *cameraPosition );

//----------------------------------------------------------
#endif

